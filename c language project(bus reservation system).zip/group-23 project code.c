#include <stdio.h>
#include <string.h>
int bill,tax;
float total_amnt,return_amnt;
char signup,signin,seat,user,busses,point,kilometers,cancellation,reason;
char user_name[20],mobile_no[10],mobile_no1[10],otp[4];
char password[10],password1[10];
char full_name[50],mobile_no[10],mail_id[30];
char booking_id[20],otpcan[4];
int main()
{
    printf("******************signup******************\n");
	printf("enter user_name:");
	scanf("%s",&user_name);
	printf("%s",user_name);
	printf("\nenter mobile_no:");
	scanf("%s",&mobile_no);
	printf("%s",mobile_no);
	printf("\nenter otp:");
	scanf("%s",&otp);
	printf("%s",otp);
    printf("\nset password:");
	scanf("%s",&password);
	printf("%s",password);
	
	printf("\n\n******************signin******************\n");
	printf("enter mobile_no1:");
	scanf("%s",&mobile_no1);
	printf("%s",mobile_no1);
	printf("\nenter valied_password:");
	scanf("%s",&password1);
	printf("%s",password1);
	
	if (strcmp(password,password1)==0 && strcmp(mobile_no,mobile_no1)==0)
	{
	    printf("\nwelcome to online bus ticket reservation system\n");
	}    
	else 
	{
	    printf("\noops.. you entered wrong password(OR)mobile_no1");
	    return 0;
	}
	printf("\n******************personal info*****************\n");
	printf("enter name:");
	scanf("%s",&user_name);
	printf("%s",user_name);
	printf("\nenter mobile_no:");
	scanf("%s",&mobile_no);
	printf("%s",mobile_no);
	printf("\nenter mail_id:");
	scanf("%s",&mail_id);
	printf("%s",mail_id);
	
	printf("\n\n********************busses**********************");
	printf("\nselect busses according to your place & destination:");
	scanf("%d",&busses);
	printf("%d",busses);
	    printf("\nbus no\t\t\t\tdate\t\t\t\ttime\t\t\t\troute");
	switch(busses)
	{
	    case 1:
	    printf("\nAP31FU0987\t\t\t-\t\t\t6:00AM-8:40AM\t\t\tsrikakulam-vishakapatanam");
	    break;
	    case 2:
	    printf("\nAP31FU0987\t\t\t-\t\t\t6:00PM-8:40PM\t\t\tvishakapatanam-srikakulam");
	    break;
	    case 3:
	    printf("\nAP31DS7098\t\t\t-\t\t\t07:00AM-10:20AM\t\t\tbhimavaram-vijayawada");
	    break;
	    case 4:
	    printf("\nAP31DS7098\t\t\t-\t\t\t06:00PM-09:20PM\t\t\tvijayawada-bhimavaram");
	    break;
	}
	
	printf("\n\n********************seat no*********************");
	printf("\nselect the seat no you want:");
	scanf("%d",&seat);
	printf("%d\n",seat);
    switch(seat)
    {
        case 1:
        printf("\n \tyou'have selected seat no=1");
        break;
        case 2:
        printf("\n \tyou'have selected seat no=2");
        break;
        case 3:
        printf("\n \tyou'have selected seat no=3");
        break;
        case 4: 
        printf("\n \tyou'have selected seat no=4");
        break;
        case 5:
        printf("\n \tyou'have selected seat no=5");
        break;
        case 6:
        printf("\n \tyou'have selected seat no=6");
        break;
        case 7:
        printf("\n \tyou'have selected seat no=7");
        break;
        case 8:
        printf("\n \tyou'have selected seat no=8");
        break;
        case 9:
        printf("\n \tyou'have selected seat no=9");
        break;
        case 10:
        printf("\n \tyou'have selected seat no=10");
        break;
        case 11:
        printf("\n \tyou'have selected seat no=11");
        break;
        case 12:
        printf("\n \tyou'have selected seat no=12");
        break;
        case 13:
        printf("\n \tyou'have selected seat no=13");
        break;
        case 14:
        printf("\n \tyou'have selected seat no=14");
        break;
        case 15:
        printf("\n \tyou'have selected seat no=15");
        break;
        case 16:
        printf("\n \tyou'have selected seat no=16");
        break;
        case 17:
        printf("\n \tyou'have selected seat no=17");
        break;
        case 18:
        printf("\n \tyou'have selected seat no=18");
        break;
        case 19:
        printf("\n \tyou'have selected seat no=19");
        break;
        case 20:
        printf("\n \tyou'have selected seat no=20");
        break;
        case 21:
        printf("\n \tyou'have selected seat no=21");
        break;
        case 22:
        printf("\n \tyou'have selected seat no=22");
        break;
        case 23:
        printf("\n \tyou'have selected seat no=23");
        break;
        case 24:
        printf("\n \tyou'have selected seat no=24");
        break;
        case 25:
        printf("\n \tyou'have selected seat no=25");
        break;
        case 26:
        printf("\n \tyou'have selected seat no=26");
        break;
        case 27:
        printf("\n \tyou'have selected seat no=27");
        break;
        case 28:
        printf("\n \tyou'have selected seat no=28");
        break;
        case 29:
        printf("\n \tyou'have selected seat no=29");
        break;
        case 30:
        printf("\n \tyou'have selected seat no=30");
        break;
        case 31:
        printf("\n \tyou'have selected seat no=31");
        break;
        case 32:
        printf("\n \tyou'have selected seat no=32");
        break;
        case 33:
        printf("\n \tyou'have selected seat no=33");
        break;
        case 34:
        printf("\n \tyou'have selected seat no=34");
        break;
        case 35:
        printf("\n \tyou'have selected seat no=35");
        break;
        case 36:
        printf("\n \tyou'have selected seat no=36");
        break;
        case 37:
        printf("\n \tyou'have selected seat no=37");
        break;
        case 38:
        printf("\n \tyou'have selected seat no=38");
        break;
        case 39:
        printf("\n \tyou'have selected seat no=39");
        break;
        case 40:
        printf("\n \tyou'have selected seat no=40");
        break;
        case 41:
        printf("\n \tyou'have selected seat no=41");
        break;
        case 42:
        printf("\n \tyou'have selected seat no=42");
        break;
        case 43:
        printf("\n \tyou'have selected seat no=43");
        break;
        case 44:
        printf("\n \tyou'have selected seat no=44");
        break;
        case 45:
        printf("\n \tyou'have selected seat no=45");
        break;
        case 46:
        printf("\n \tyou'have selected seat no=46");
        break;
        case 47:
        printf("\n \tyou'have selected seat no=47");
        break;
        case 48:
        printf("\n \tyou'have selected seat no=48");
        break;
    }
    
    printf("\n\n********************pickup_point and destination_point**********************");
	printf("\nselect what is your pickup_point and destination_point:");
	scanf("%d",&point);
	printf("%d",point);
	    printf("\npickup_point\t\t\t\t\t\t\tdestination_point");
	switch(point)
	{
	    case 1:
	    printf("\nsrikakulam busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 2:
	    printf("\netcherla busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 3:
	    printf("\nadapaka busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 4:
	    printf("\nranastalam busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 5:
	    printf("\npydibimavaram busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 6:
	    printf("\npusapatirega busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 7:
	    printf("\nbhogapuram busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 8:
	    printf("\nthagarapuvasala busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 9:
	    printf("\nnarayana gajapathirajupuram busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 10:
	    printf("\nsimhachalam busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 11:
	    printf("\ngopalapatnam busstop\t\t\t\t\t\t\tvishakapatanam busstop");
	    break;
	    case 12:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tsrikakulam busstop");
	    break;
	    case 13:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tetcherla busstop");
	    break;
	    case 14:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tadapaka busstop");
	    break;
	    case 15:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tranastalam busstop");
	    break;
	    case 16:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tpydibimavaram busstop");
	    break;
	    case 17:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tpusapatirega busstop");
	    break;
	    case 18:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tbhogapuram busstop");
	    break;
	    case 19:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tthagarapuvasala busstop");
	    break;
	    case 20:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tnarayana gajapathirajupuram busstop");
	    break;
	    case 21:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tsimhachalam busstop");
	    break;
	    case 22:
	    printf("\nvishakapatnam busstop\t\t\t\t\t\t\tgopalapatnam busstop");
	    break;
	    case 23:
	    printf("\nbhimavaram busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 24:
	    printf("\nundi busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 25:
	    printf("\nakividu busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 26:
	    printf("\npallevada busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 27:
	    printf("\nkaikaluru busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 28:
	    printf("\nmandavalli busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 29:
	    printf("\nmudenepalli busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 30:
	    printf("\ngudivada busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 31:
	    printf("\npamarru busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 32:
	    printf("\nvuyyuru busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 33:
	    printf("\nkankipadu busstop\t\t\t\t\t\t\tvijayawada busstop");
	    break;
	    case 34:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tbhimavaram busstop");
	    break;
	    case 35:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tundi busstop");
	    break;
	    case 36:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\takividu busstop");
	    break;
	    case 37:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tpallevada busstop");
	    break;
	    case 38:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tkaikaluru busstop");
	    break;
	    case 39:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tmandavalli busstop");
	    break;
	    case 40:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tmudinepalli busstop");
	    break;
	    case 41:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tgudivada busstop");
	    break;
	    case 42:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tpamarru busstop");
	    break;
	    case 43:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tvuyyuru busstop");
	    break;
	    case 44:
	    printf("\nvijayawada busstop\t\t\t\t\t\t\tkankipadu busstop");
	    break;
	}
	
	printf("\n\n********************conformation of payment&ticket**********************");
	printf("\nenter kilometers travelled:");
	scanf("%d",&kilometers);
	printf("%d",kilometers);
    {
        bill=kilometers*10;
        tax=bill*5/100;
        total_amnt=bill+tax;
        printf("\ntotal_amnt=%.2f",bill,tax,total_amnt);
        printf("\nafter payment done conformation of payment&ticket will be sent to your mobile_no with booking_id");
        printf("\nthank you for choosing our csn transport,\nhappy journey");
    }
    
    printf("\n\n********************cancellation of ticket**********************");
    printf("\nyou will receive only 90percentage from total amount paid");
    printf("\nenter booking_id:");
	scanf("%s",&booking_id);
	printf("%s",booking_id);
	printf("\nreason for cancellation:");
	scanf("%d",&reason);
	printf("%d",reason);
	switch(reason)
	{
	    case 1:
	    printf("\nnot feeling well");
	    break;
	    case 2:
	    printf("\nprogram was cancled unfortunately");
	    break;
	    case 3:
	    printf("\nhad work on that time");
	    break;
	}
	printf("\nenter otpcan:");
    scanf("%s",&otpcan);
	printf("%s",otpcan);
	{
	    return_amnt=total_amnt*90/100;
	    printf("\nreturn_amnt=%f",return_amnt);
	    printf("\nyour payment will receive soon and ticket will be cancled");
	 }     
}


